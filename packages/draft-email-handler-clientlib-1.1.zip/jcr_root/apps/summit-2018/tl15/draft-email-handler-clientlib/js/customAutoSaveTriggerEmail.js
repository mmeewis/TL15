
console.log("init customAutoSaveTriggerEmail");

window.addEventListener("bridgeInitializeStart", function (){   
    guideBridge.connect(function () { guideBridge.on("elementValueChanged", function (event,data) { 
        console.log("data.target.name : " + data.target.name);
        if(data.target.name === 'email') {
            console.log("trigger => emailValueChanged");
            guideBridge.trigger("emailValueChanged");
        }
    });
   });
});
