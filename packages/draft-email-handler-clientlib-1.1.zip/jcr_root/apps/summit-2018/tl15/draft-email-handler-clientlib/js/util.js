$(function() {

   /* $('.guideContainerWrapperNode').off('swipeleft swiperight', function(e){
        console.log("doing nothing");
    });*/
/*Switching off the swipe gesture!*/
    window.setTimeout(function() {

 $('.guideContainerWrapperNode').off('swipeleft');
 $('.guideContainerWrapperNode').off('swiperight');
    }, 1000);

});
